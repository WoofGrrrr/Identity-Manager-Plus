start "" gvim -S identityImporter.css.session.vim
start "" gvim -S identityImporter.html.session.vim
start "" gvim -S identityImporter.js.session.vim
exit
