start "" gvim -S identityEditor.css.session.vim
start "" gvim -S identityEditor.html.session.vim
start "" gvim -S identityEditor.js.session.vim
exit
