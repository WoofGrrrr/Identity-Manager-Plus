start "" gvim -S identityChooser.css.session.vim
start "" gvim -S identityChooser.html.session.vim
start "" gvim -S identityChooser.js.session.vim
exit
